//
//  LEANCustomAction.m
//  GoNativeIOS
//
//  Created by Weiyin He on 4/17/14.
// Copyright (c) 2014 GoNative.io LLC. All rights reserved.
//

#import "LEANCustomAction.h"

@implementation LEANCustomAction
+ (NSArray*)actionsForUrl:(NSURL*)url
{    
    return nil;
}
@end
